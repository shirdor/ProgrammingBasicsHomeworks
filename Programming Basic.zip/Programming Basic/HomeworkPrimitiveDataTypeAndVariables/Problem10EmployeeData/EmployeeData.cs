﻿using System;

class EmployeeData
{
    static void Main()
    {
        string firstName = "Krasi";
        string lastName = "Balchev";
        int age = 16;
        char gender = 'm';
        string id = "9403237564";
        string employeeNumber = "1527382";
        Console.WriteLine("First name: " + firstName);
        Console.WriteLine("Last name: " + lastName);
        Console.WriteLine("Age: " + age);
        Console.WriteLine("Gender: " + gender);
        Console.WriteLine("Personal ID: " + id);
        Console.WriteLine("Unique Employee number: " + employeeNumber);
    }
}

