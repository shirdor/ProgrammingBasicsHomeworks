﻿using System;

class ComparingFloats
{
    static void Main()
    {
        double a = double.Parse(Console.ReadLine());
        double b = double.Parse(Console.ReadLine());
        double difference = Math.Abs(a - b);
        double eps = 0.000001;
        if (difference >= eps)
        {
            Console.WriteLine(false);
        }
        else
        {
            Console.WriteLine(true);            
        }
    }
}

