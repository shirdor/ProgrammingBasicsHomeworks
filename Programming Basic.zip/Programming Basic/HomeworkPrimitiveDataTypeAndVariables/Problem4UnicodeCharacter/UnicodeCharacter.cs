﻿using System;

class UnicodeCharacter
{
    static void Main()
    {
        Char symbol = '\u002A';
        Console.WriteLine(symbol);
    }
}

