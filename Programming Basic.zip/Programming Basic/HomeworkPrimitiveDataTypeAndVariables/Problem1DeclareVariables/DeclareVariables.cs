﻿using System;

class DeclareVariables
{
    static void Main()
    {
        SByte firstNumber = 97;
        SByte secondNumber = -115;
        short thirdNumber = -10000;
        ushort forthNumber = 52130;
        uint fifthNumber = 4825932;
        Console.WriteLine(firstNumber);
        Console.WriteLine(secondNumber);
        Console.WriteLine(thirdNumber);
        Console.WriteLine(forthNumber);
        Console.WriteLine(fifthNumber);
    }
}

