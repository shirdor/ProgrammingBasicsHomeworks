﻿using System;

class FloatOrDouble
{
    static void Main()
    {
        Double firstNumber = 34.56783902D;
        float secondNumber = 12.345F;
        Double thirdNumber = 8923.1234857D;
        float forthNumber = 3456.091F;
        Console.WriteLine("{0}\n{1}\n{2}\n{3}", firstNumber, secondNumber, thirdNumber, forthNumber);


    }
}
