﻿using System;

class IsoscelesTriangle
{
    static void Main()
    {
        char symbol = '\u00A9';
        Console.WriteLine("   " + symbol);
        Console.WriteLine("  " + symbol + " " + symbol);
        Console.WriteLine(" " + symbol + "   " + symbol);
        Console.WriteLine(symbol + " " + symbol + " " + symbol + " " + symbol);
    }
}

