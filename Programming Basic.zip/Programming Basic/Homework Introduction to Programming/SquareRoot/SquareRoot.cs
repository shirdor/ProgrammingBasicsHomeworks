﻿using System;
   
class SquareRoot
{
    static void Main()
    {
         Console.Write("kvadratniqt koren na 12345 e = ");
         Console.WriteLine(Math.Sqrt(12345));
    }
}       
    
