﻿using System;

class MyFirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("Antonio");
        Console.WriteLine("Buyukliev");
    }
}

