﻿using System;

class Sort3NumbersWithNestedIfs
{
    static void Main()
    {
        Console.WriteLine("enter first number");
        double firstNumber = double.Parse(Console.ReadLine());
        Console.WriteLine("enter second number");
        double secondNumber = double.Parse(Console.ReadLine());
        Console.WriteLine("enter third number");
        double thirdNumber = double.Parse(Console.ReadLine());
        if (firstNumber >= secondNumber && firstNumber >= thirdNumber)
        {
            if (secondNumber >= thirdNumber)
            {
                Console.WriteLine($"{firstNumber} {secondNumber} {thirdNumber}");
            }
            else
            {
                Console.WriteLine($"{firstNumber} {thirdNumber} {secondNumber} ");
            }
        if (secondNumber >= firstNumber && secondNumber >= thirdNumber)
        {
            if (firstNumber >= thirdNumber)
            {
                Console.WriteLine($"{secondNumber} {firstNumber} {thirdNumber}");
            }
            else
            {
                Console.WriteLine($"{secondNumber} {thirdNumber} {firstNumber}");
            }
            if (thirdNumber >= firstNumber && thirdNumber >= secondNumber)
            {
                if (firstNumber >= secondNumber)
                {
                    Console.WriteLine($"{thirdNumber} {firstNumber} {secondNumber}");
                }
                else
                {
                    Console.WriteLine($"{thirdNumber} {secondNumber} {firstNumber}");
                }
                }
            }
        }
    }
}

