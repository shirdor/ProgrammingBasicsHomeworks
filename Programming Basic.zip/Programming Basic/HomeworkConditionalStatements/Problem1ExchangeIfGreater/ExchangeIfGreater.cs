﻿using System;

class ExchangeIfGreater
{
    static void Main()
    {
        Console.WriteLine("enter first number");
        double firstNumber = double.Parse(Console.ReadLine());
        Console.WriteLine("enter second number");
        double secondNumber = double.Parse(Console.ReadLine());
        if (firstNumber > secondNumber)
        {
            double someVariable = firstNumber;
            firstNumber = secondNumber;
            secondNumber = someVariable;
            Console.WriteLine("{0} {1}", firstNumber, secondNumber);
        }
        else
        {
            Console.WriteLine("{0} {1}", firstNumber, secondNumber);
        }
    }
}

