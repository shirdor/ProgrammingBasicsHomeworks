﻿using System;

class MultiplicationSign
{
    static void Main()
    {
        Console.WriteLine("enter a");
        double a = double.Parse(Console.ReadLine());
        Console.WriteLine("enter b");
        double b = double.Parse(Console.ReadLine());
        Console.WriteLine("enter c");
        double c = double.Parse(Console.ReadLine());
        int possitiveCounter = 0;
        if (a > 0)
        {
            possitiveCounter++;
        }
        if (b > 0)
        {
            possitiveCounter++;
        }
        if (c > 0)
        {
            possitiveCounter++;
        }     
        if (possitiveCounter == 1 || possitiveCounter == 3)
        {
            Console.WriteLine("+");
        }
        else if (a == 0 || b == 0 || c == 0)
        {
            Console.WriteLine("0");
        }   
        else
        {
            Console.WriteLine("-");
        }
    }
}
