﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class BeerTime
{
    static void Main()
    {
        Console.WriteLine("enters a time in format (hh:mm tt)");
        string givenTime = Console.ReadLine();
        DateTime dateValue;
        if (DateTime.TryParse(givenTime, out dateValue))
        {
            DateTime newGivenTime = Convert.ToDateTime(givenTime);
            string startTime = "13:00:00";
            DateTime beginningOfTheBeerTime = Convert.ToDateTime(startTime);
            string endTime = "03:00:00";
            DateTime finishOfTheBeerTime = Convert.ToDateTime(endTime);
            if (newGivenTime >= beginningOfTheBeerTime ||
                newGivenTime <= finishOfTheBeerTime)
            {
                Console.WriteLine("beer time");
            }
            else
            {
                Console.WriteLine("non - beer time");
            }
        }
        else
        {
            Console.WriteLine("invalid time");
        }
    }
}

