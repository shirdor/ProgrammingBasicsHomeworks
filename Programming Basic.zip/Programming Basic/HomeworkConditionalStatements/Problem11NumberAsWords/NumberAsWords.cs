﻿using System;

class NumberAsWords
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int firstDigit = n % 10;
        int seconddigit = (n / 10) % 10;
        int thirdDigit = n / 100;
        int fromTenToTwenty = n % 100;
        string numberName = "";
        switch (thirdDigit)
        {
            case 1:
            Console.Write("one hundred ");
            break;
            case 2:
            Console.Write("two hundred ");
            break;
            case 3:
            Console.Write("three hundred ");
            break;
            case 4:
            Console.Write("four hundred ");
            break;
            case 5:
            Console.Write("five hundred ");
            break;
            case 6:
            Console.Write("six hundred ");
            break;
            case 7:
            Console.Write("seven hundred ");
            break;
            case 8:
            Console.Write("eight hundred ");
            break;
            case 9:
            Console.Write("nine hundred ");
            break;
            default:
                break;
        }
        if (n % 100 != 0 && n > 100)
        {
            Console.Write("and ");
        }
        switch (seconddigit)
        {
            case 1:
                switch (fromTenToTwenty)
                {
                    case 10:
                    Console.Write("ten");
                    break;
                    case 11:
                    Console.Write("eleven");
                    break;
                    case 12:
                    Console.Write("twelve");
                    break;
                    case 13:
                    Console.Write("thirteen");
                    break;
                    case 14: 
                    Console.Write("forteen");
                    break;
                    case 15:
                    Console.Write("fifteen");
                    break;
                    case 16:
                    Console.Write("sixteen");
                    break;
                    case 17:
                    Console.Write("seventteen");
                    break;
                    case 18:
                    Console.Write("eighteen ");
                    break;
                    case 19:
                    Console.Write("nineteen");
                    break;
                    default:
                        break;
                }
                break;
            case 2:
            Console.Write("twenty ");
            break;
            case 3:
            Console.WriteLine("thirty ");                
            break;
            case 4:
            Console.Write("forty ");
            break;
            case 5:
            Console.Write("fifty ");
            break;
            case 6:
            Console.Write("sixty ");
            break;
            case 7:
            Console.Write("seventy ");
            break;
            case 8:
            Console.Write("eighty ");
            break;
            case 9:
            Console.Write("ninety ");
            break;
            default:
            Console.WriteLine("");
                break;
        }
        if (fromTenToTwenty >= 10 && fromTenToTwenty < 20)
        {
            return;
        }
        switch (firstDigit)
        {
            case 1:
            Console.Write("one");
            break;
            case 2:                    
            Console.Write("two");
            break;
            case 3:
            Console.Write("three");
            break;
            case 4:
            Console.Write("four");
            break;
            case 5:
            Console.Write("five");
            break;
            case 6:
            Console.Write("six");
            break;
            case 7:         
            Console.Write("seven");
            break;
            case 8:                    
            Console.Write("eight");
            break;
            case 9:
            Console.Write("nine");
            break;
            default:
                break;
        }
        if (n == 0)
        {
            Console.WriteLine("zero");
        }     
    }
}